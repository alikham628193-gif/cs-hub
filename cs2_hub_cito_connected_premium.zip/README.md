# CS2 HUB

Static CS2 esports dashboard with a Netlify Function proxy for Cito API.

## Deploy
- Netlify build publish directory: `.`
- Functions directory: `netlify/functions`
- Add `CITO_API_KEY` under Netlify environment variables. Never put the real key in HTML, GitHub, or `.env` committed to the repository.
- Redeploy after changing environment variables.

## Notes
- The player cards use portrait/image URLs if the API returns them. If the API does not provide images, a stylized animated fallback avatar is shown.
- The site cannot show live scores, official player photos, or stats until the API key and supported endpoints return those fields.
